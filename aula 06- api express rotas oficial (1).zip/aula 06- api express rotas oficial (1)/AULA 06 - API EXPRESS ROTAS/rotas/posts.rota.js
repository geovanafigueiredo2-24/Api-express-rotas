const express = require('express')
const router  = express.Router()
const {v4: uuidv4 } = require('uuid');


const posts = {}

router.post('/', (req, res) => {
    const posts= req.body
    const idPost = uuidv4()
    console.log(posts)
    posts.id = idPost
   
    posts[idPost] = posts
    res.json({msg: "post adicionado com sucesso!!"})
})


router.get('/', (req, res) => {
    res.json({post: Object.values(posts)})
})

router.put('/', (req, res) => {
    const id = req.query.id
    if (id && posts[id]){
        const post = req.body
        post.id = id
        posts[id] = post
        res.json({msg: "post atualizado com sucesso!!"})
    }else{
        res.status(400).json({msg: "post não encontrado!!"})
    }

})

router.delete('/', (req, res) => {
    const id = req.query.id
    if (id && posts[id]){
        delete posts[id]
        res.json({msg: "post deletado com sucesso!!"})
    }else{
        res.status(400).json({msg: "post  não encontrado!!"})
    }
})


module.exports = router 
