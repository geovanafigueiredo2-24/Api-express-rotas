const express = require('express')
const router  = express.Router()
const {v4: uuidv4 } = require('uuid');


const usuarios = {}

router.post('/', (req, res) => {
    const usuarios= req.body
    const idUsuario = uuidv4()
    console.log(usuarios)
    usuarios.id = idUsuario
   
    usuarios[idUsuario] = usuarios
    res.json({msg: "usuario adicionado com sucesso!!"})
})


router.get('/', (req, res) => {
    res.json({usuario: Object.values(usuarios)})
})

router.put('/', (req, res) => {
    const id = req.query.id
    if (id && usuarios[id]){
        const usuario = req.body
        usuario.id = id
        usuarios[id] = usuario
        res.json({msg: "usuario atualizado com sucesso!!"})
    }else{
        res.status(400).json({msg: "post não encontrado!!"})
    }

})

router.delete('/', (req, res) => {
    const id = req.query.id
    if (id && usuarios[id]){
        delete usuarios[id]
        res.json({msg: "usuario deletado com sucesso!!"})
    }else{
        res.status(400).json({msg: "usuario não encontrado!!"})
    }
})


module.exports = router 
